package com.example.noriter;

import android.graphics.drawable.Drawable;

/**
 * Created by 전효승 on 2018-03-10.
 */

public class TagViewItem {
    private Drawable image ;

    public void setImage(Drawable icon) {
        image = icon ;
    }

    public Drawable getImage() {
        return this.image ;
    }
}